package handlers

import (
	"TODOLIST_Tasks/app/internal/apperror"
	"TODOLIST_Tasks/app/internal/handlers"
	model2 "TODOLIST_Tasks/app/internal/tasks/model"
	"TODOLIST_Tasks/app/internal/tasks/service"
	"TODOLIST_Tasks/app/pkg/api/filter"
	sort2 "TODOLIST_Tasks/app/pkg/api/sort"
	logging2 "TODOLIST_Tasks/app/pkg/logging"
	"TODOLIST_Tasks/app/pkg/utils/CacheKey"
	"TODOLIST_Tasks/app/pkg/utils/translator"
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/google/uuid"
	"github.com/julienschmidt/httprouter"
	"io"
	"net/http"
)

const (
	taskURL        = "/tasks/:uuid"
	tasksByUserURL = "/v1/users/:userId/tasks"
	tasksByTags    = "/v1/users/:userId/tags/:tagsId/tasks"
)

type Handler struct {
	service *service.Service
	logger  *logging2.Logger
}

func NewHandler(service *service.Service) handlers.Handler {
	return &Handler{
		service: service,
		logger:  logging2.GetLogger().GetLoggerWithField("handler", "tasks"),
	}
}

func (h *Handler) Register(router *httprouter.Router) {
	router.HandlerFunc(http.MethodPost, tasksByUserURL, apperror.Middleware(h.Create))
	router.HandlerFunc(http.MethodPatch, taskURL, apperror.Middleware(h.Update))
	router.HandlerFunc(http.MethodGet, taskURL, apperror.Middleware(h.FindOne))
	router.HandlerFunc(http.MethodGet, tasksByUserURL, filter.Middleware(sort2.MiddleWare(apperror.Middleware(h.GetList), "due_date", sort2.ASC)))
	router.HandlerFunc(http.MethodDelete, taskURL, apperror.Middleware(h.Delete))
	router.HandlerFunc(http.MethodGet, tasksByTags, filter.Middleware(sort2.MiddleWare(apperror.Middleware(h.GetListByTag), "due_date", sort2.ASC)))
}

func (h *Handler) Create(w http.ResponseWriter, r *http.Request) error {
	h.logger.Info("CreateTask called")

	params := httprouter.ParamsFromContext(r.Context())
	userId := params.ByName("userId")
	if userId == "" {
		h.logger.Warn("missing userId parameter in Create")
		http.Error(w, "Invalid user ID", http.StatusBadRequest)
		return nil
	}

	body, err := io.ReadAll(r.Body)
	if err != nil {
		h.logger.Errorf("failed to read request body: %v", err)
		http.Error(w, "Failed to read request body", http.StatusInternalServerError)
		return err
	}
	defer r.Body.Close()

	var taskDTO model2.TaskCreateDTO
	if err = taskDTO.UnmarshalJSON(body); err != nil {
		h.logger.Errorf("failed to unmarshal request body: %v", err)
		http.Error(w, "Invalid request payload", http.StatusBadRequest)
		return err
	}

	task := model2.Task{
		Id:          uuid.New().String(),
		Title:       taskDTO.Title,
		Description: taskDTO.Description,
		Priory:      taskDTO.Priory,
		Status:      taskDTO.Status,
		DueDate:     taskDTO.DueDate,
		UserID:      userId,
		TagID:       taskDTO.TagID,
		TagsName:    taskDTO.TagName,
	}

	ctx := r.Context()
	taskResult, err := h.service.CreateTask(ctx, task)
	if err != nil {
		h.logger.Errorf("failed to create task: %v", err)
		http.Error(w, "Failed to save task", http.StatusInternalServerError)
		return err
	}

	h.logger.Infof("Task created successfully with ID: %s", taskResult.Id)

	w.WriteHeader(http.StatusCreated)
	w.Write([]byte(fmt.Sprintf("Task created with ID: %s", taskResult.Id)))

	go func(taskResult model2.Task) {
		if err := h.service.CreateTaskRedis(context.Background(), taskResult); err != nil {
			h.logger.Errorf("failed to copy task to Redis: %v", err)
		}
	}(taskResult)

	return nil
}

func (h *Handler) Update(w http.ResponseWriter, r *http.Request) error {
	h.logger.Info("UpdateTask called")

	params := httprouter.ParamsFromContext(r.Context())
	id := params.ByName("uuid")
	if id == "" {
		h.logger.Warn("missing uuid parameter in Update")
		http.Error(w, "Invalid ID", http.StatusBadRequest)
		return errors.New("invalid ID")
	}

	var taskRequest model2.TaskUpdateDTO
	if err := json.NewDecoder(r.Body).Decode(&taskRequest); err != nil {
		h.logger.Errorf("failed to decode request body: %v", err)
		http.Error(w, "Invalid input", http.StatusBadRequest)
		return err
	}

	newTask, err := h.service.UpdateTask(r.Context(), id, taskRequest)
	if err != nil {
		h.logger.Errorf("failed to update task with ID %s: %v", id, err)
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return err
	}

	h.logger.Infof("Task with ID %s updated successfully", id)

	response := map[string]string{"message": "successful update"}
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(response)

	go func(taskResult model2.Task) {

		if err = h.service.DeleteTaskRedis(context.Background(), taskResult.Id); err != nil {
			h.logger.Errorf("failed to delete task from Redis: %v", err)
			return
		}

		if err = h.service.UpdateTaskRedis(context.Background(), taskResult); err != nil {
			h.logger.Errorf("failed to update task in Redis: %v", err)
		}
	}(newTask)

	return nil
}

func (h *Handler) Delete(w http.ResponseWriter, r *http.Request) error {
	h.logger.Info("DeleteTask called")

	params := httprouter.ParamsFromContext(r.Context())
	id := params.ByName("uuid")
	if id == "" {
		h.logger.Warn("missing uuid parameter in Delete")
		http.Error(w, "Invalid ID", http.StatusBadRequest)
		return nil
	}

	ctx := r.Context()
	_, err := h.service.DeleteTask(ctx, id)
	if err != nil {
		h.logger.Errorf("failed to delete task with ID %s: %v", id, err)
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return err
	}

	h.logger.Infof("Task with ID %s deleted successfully", id)

	response := map[string]string{"message": "successful delete"}
	w.WriteHeader(http.StatusOK)
	json.NewEncoder(w).Encode(response)

	go func(taskID string) {
		if err := h.service.DeleteTaskRedis(context.Background(), taskID); err != nil {
			h.logger.Errorf("failed to delete task from Redis: %v", err)
		}
	}(id)

	h.logger.Infof("Task with ID %s deleted Redis successfully", id)

	return nil
}

func (h *Handler) GetListByTag(w http.ResponseWriter, r *http.Request) error {
	h.logger.Info("GetListByTag called")

	params := httprouter.ParamsFromContext(r.Context())
	userId := params.ByName("userId")
	tagId := params.ByName("tagsId")
	if userId == "" || tagId == "" {
		h.logger.Warn("missing userId or tagId parameter in GetListByTag")
		http.Error(w, "Invalid user ID or tag ID", http.StatusBadRequest)
		return errors.New("invalid user ID or tag ID")
	}

	var filterOptions filter.Option
	if fOptions, ok := r.Context().Value(filter.OptionsContextKey).([]filter.Field); ok {
		filterOptions.Fields = fOptions
	}

	var sortOptions sort2.Options
	if sOptions, ok := r.Context().Value(sort2.OptionsContextKey).(sort2.Options); ok {
		sortOptions = sOptions
	}

	cacheKey := CacheKey.BuildCacheKeyWithTag(userId, tagId, filterOptions, sortOptions)

	tasks, err := h.service.GetTasksFromCache(r.Context(), cacheKey)
	if err == nil && len(tasks) > 0 {
		h.logger.Infof("Tasks retrieved from cache for userId=%s tagId=%s", userId, tagId)

		responses := make([]model2.TaskResponse, 0, len(tasks))
		for _, task := range tasks {
			responses = append(responses, model2.TaskResponse{
				Id:          task.Id,
				Title:       task.Title,
				Description: task.Description,
				Priory:      task.Priory,
				Status:      translator.Translator(task.Status),
				DueDate:     translator.FormatDate(task.DueDate),
				CreatedAt:   translator.FormatDate(task.CreatedAt),
				UserId:      task.UserID,
				TagsName:    task.TagsName,
			})
		}

		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		return json.NewEncoder(w).Encode(responses)
	}

	tasks, err = h.service.FindAllByTag(r.Context(), userId, tagId)
	if err != nil {
		h.logger.Errorf("failed to find tasks by tag: %v", err)
		http.Error(w, "Error finding tasks", http.StatusInternalServerError)
		return err
	}

	if len(tasks) == 0 {
		h.logger.Infof("no tasks found for userId=%s tagId=%s", userId, tagId)
		w.WriteHeader(http.StatusNoContent)
		return nil
	}

	responses := make([]model2.TaskResponse, 0, len(tasks))
	for _, task := range tasks {
		responses = append(responses, model2.TaskResponse{
			Id:          task.Id,
			Title:       task.Title,
			Description: task.Description,
			Priory:      task.Priory,
			Status:      translator.Translator(task.Status),
			DueDate:     translator.FormatDate(task.DueDate),
			CreatedAt:   translator.FormatDate(task.CreatedAt),
			UserId:      task.UserID,
			TagsName:    task.TagsName,
		})
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	if err := json.NewEncoder(w).Encode(responses); err != nil {
		h.logger.Errorf("failed to encode response: %v", err)
		http.Error(w, "Error encoding response", http.StatusInternalServerError)
		return err
	}

	go func(tasks []model2.Task) {
		if err := h.service.SetTasksToCache(context.Background(), cacheKey, tasks); err != nil {
			h.logger.Errorf("failed to copy task to Redis: %v", err)
		}
	}(tasks)

	return nil
}

func (h *Handler) FindOne(w http.ResponseWriter, r *http.Request) error {
	h.logger.Info("FindOne called")

	params := httprouter.ParamsFromContext(r.Context())
	id := params.ByName("uuid")
	if id == "" {
		h.logger.Warn("missing uuid parameter in FindOne")
		http.Error(w, "Identifier is required", http.StatusBadRequest)
		return nil
	}

	// Пробуем найти задачу в Redis
	taskRedis, err := h.service.FindOneRedis(r.Context(), id)
	if err == nil && taskRedis.Id != "" {
		h.logger.Infof("Task with ID %s found in Redis", id)

		// Отправляем задачу из Redis
		response := model2.TaskResponse{
			Id:          taskRedis.Id,
			Title:       taskRedis.Title,
			Description: taskRedis.Description,
			Priory:      taskRedis.Priory,
			Status:      translator.Translator(taskRedis.Status),
			DueDate:     taskRedis.DueDate.Format("02-01-2006 15:04"),
			CreatedAt:   taskRedis.CreatedAt.Format("02-01-2006 15:04"),
			UserId:      taskRedis.UserID,
			TagsName:    taskRedis.TagsName,
		}

		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		if err := json.NewEncoder(w).Encode(response); err != nil {
			h.logger.Errorf("failed to encode response: %v", err)
			http.Error(w, "Error encoding response", http.StatusInternalServerError)
			return err
		}
		return nil
	}

	// Если задачи нет в Redis, ищем в базе данных
	task, err := h.service.FindOneTask(r.Context(), id)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			h.logger.Warnf("task with ID %s not found in database", id)
			http.Error(w, "Task not found", http.StatusNotFound)
			return nil
		}
		h.logger.Errorf("failed to retrieve task with ID %s from database: %v", id, err)
		http.Error(w, "Failed to retrieve task", http.StatusInternalServerError)
		return err
	}

	h.logger.Infof("Task with ID %s retrieved successfully from database", id)

	// Отправляем задачу из базы данных
	response := translator.ToTaskResponse(task)

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	if err := json.NewEncoder(w).Encode(response); err != nil {
		h.logger.Errorf("failed to encode response: %v", err)
		http.Error(w, "Error encoding response", http.StatusInternalServerError)
		return err
	}

	go func(taskResult model2.Task) {
		if err := h.service.CreateTaskRedis(context.Background(), taskResult); err != nil {
			h.logger.Errorf("failed to copy task to Redis: %v", err)
		}
	}(task)

	return nil

}

func (h *Handler) GetList(w http.ResponseWriter, r *http.Request) error {
	h.logger.Info("GetList called")

	params := httprouter.ParamsFromContext(r.Context())
	userId := params.ByName("userId")
	if userId == "" {
		h.logger.Warn("missing userId parameter in GetList")
		http.Error(w, "Invalid user ID", http.StatusBadRequest)
		return nil
	}

	// Извлекаем фильтрацию
	var filterOptions filter.Option
	if fOptions, ok := r.Context().Value(filter.OptionsContextKey).([]filter.Field); ok {
		filterOptions.Fields = fOptions
	}

	// Извлекаем сортировку
	var sortOptions sort2.Options
	if sOptions, ok := r.Context().Value(sort2.OptionsContextKey).(sort2.Options); ok {
		sortOptions = sOptions
	}

	// Формируем cache key
	cacheKey := CacheKey.BuildCacheKey(userId, filterOptions, sortOptions)

	// Пробуем найти данные в Redis через сервис
	tasks, err := h.service.GetTasksFromCache(r.Context(), cacheKey)
	if err == nil && len(tasks) > 0 {
		h.logger.Infof("Tasks for user %s found in Redis", userId)

		// Сначала преобразуем данные в формат ответа
		var responses []model2.TaskResponse
		for _, task := range tasks {
			response := translator.ToTaskResponse(task)
			responses = append(responses, response)
		}

		// Отправляем данные из Redis
		w.WriteHeader(http.StatusOK)
		if err := json.NewEncoder(w).Encode(responses); err != nil {
			h.logger.Errorf("failed to encode response: %v", err)
			http.Error(w, "Error encoding response", http.StatusInternalServerError)
			return err
		}

		h.logger.Infof("Successfully returned tasks from Redis for user %s", userId)
		return nil
	}

	// Если нет в кэше — идем в базу данных
	tasks, err = h.service.FindAllTasks(r.Context(), sortOptions, filterOptions, userId)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			h.logger.Warnf("no tasks found for userID %s", userId)
			http.Error(w, "No tasks found", http.StatusNotFound)
			return nil
		}
		h.logger.Errorf("error finding tasks for userID %s: %v", userId, err)
		http.Error(w, "Error finding tasks", http.StatusInternalServerError)
		return err
	}

	if len(tasks) == 0 {
		h.logger.Infof("no tasks found for userID: %s", userId)
		w.WriteHeader(http.StatusNoContent)
		return nil
	}

	h.logger.Infof("Successfully retrieved tasks for user %s from database", userId)

	// Преобразуем задачи в формат ответа
	var responses []model2.TaskResponse
	for _, task := range tasks {
		response := model2.TaskResponse{
			Id:          task.Id,
			Title:       task.Title,
			Description: task.Description,
			Priory:      task.Priory,
			Status:      task.Status,
			DueDate:     task.DueDate.Format("02-01-2006 15:04"),
			CreatedAt:   task.CreatedAt.Format("02-01-2006 15:04"),
			UserId:      task.UserID,
			TagsName:    task.TagsName,
		}
		responses = append(responses, response)
	}

	// Возвращаем результат
	w.WriteHeader(http.StatusOK)
	err = json.NewEncoder(w).Encode(responses)
	if err != nil {
		h.logger.Errorf("failed to encode response: %v", err)
		http.Error(w, "Error encoding response", http.StatusInternalServerError)
		return err
	}

	// Запись в кэш
	go func(key string) {
		err = h.service.SetTasksToCache(context.Background(), cacheKey, tasks)
		if err != nil {
			h.logger.Errorf("failed to set tasks to cache: %v", err)
		}
	}(cacheKey)

	return nil
}
